import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Login from './components/Login';
import Signup from './components/Signup';
import Home from './components/Home';
import ShowDetails from './components/ShowDetails';
import Cart from './components/cart/Cart';
import PaymentForm from './components/PaymentForm';
import ThankYou from './components/ThankYou';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path='/' element={<Home />} />
        <Route path='/signup' element={<Signup/>} />
        <Route path='/login' element={<Login/>} />
        <Route path='/cart' element={<Cart />} />
        <Route path='/paymentForm' element={<PaymentForm />} />
        <Route path='/thankYou' element={<ThankYou />} />
        <Route path='/showDetails' element={<ShowDetails />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
