export default function ThankYou(){
    return(
        <div style={{textAlign:"center"}}>
            <img src="https://media.istockphoto.com/vectors/flag-thank-you-old-school-flag-banner-with-text-vector-id1183769974?s=612x612"/>
        </div>
        
    )
}