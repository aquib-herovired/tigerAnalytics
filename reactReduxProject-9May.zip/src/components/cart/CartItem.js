export default function CartItem(props){
    return(
        <div style={{display:"flex", justifyContent:"space-around"}}>
            <div>
                <img src={props.src} width="300px"/>
            </div>
            <div style={{maxWidth:"200px"}}>
                <h3>{props.title}</h3>
                <p>{props.price}</p>
            </div>
        </div>
    )
}