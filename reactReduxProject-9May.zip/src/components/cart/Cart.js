import CartItem from "./CartItem";

export default function Cart(){
    return(
        <div>
        <h2 style={{textAlign:"center"}}>Your Cart</h2>
            <CartItem src="https://images.unsplash.com/photo-1648737966636-2fc3a5fffc8a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" title="Game One" price="499" />
            <br/>
            <CartItem src="https://images.unsplash.com/photo-1648737966636-2fc3a5fffc8a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" title="Game Two" price="999" />
        </div>
    )
}