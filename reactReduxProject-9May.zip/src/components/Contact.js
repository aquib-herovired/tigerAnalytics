export default function Contact(){
    return(
        <h1>This is the Contact page</h1>
    );
}