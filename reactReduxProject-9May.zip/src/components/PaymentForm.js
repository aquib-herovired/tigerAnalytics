import React, {Component} from 'react'

class PaymentForm extends Component{
    constructor(){
        super();
    }

    render(){
        return(
            <div>
                <h3>Payment Form</h3>
                <form action="" method="POST">
                    <input type="text" placeholder='Enter your name'/>
                    <br/>
                    <input type="text" placeholder="Enter your father's name"/>
                    <br/>
                    <input type="text" placeholder="Enter your bank name name"/>
                    <br/>
                    <input type="text" placeholder="Enter your debit card number"/>
                    <br/>
                    <input type="submit"/>
                </form>
            </div>
        )
    }
}

export default PaymentForm;