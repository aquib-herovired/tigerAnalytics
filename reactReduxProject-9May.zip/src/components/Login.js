import React, {Component} from 'react'

class Login extends Component{
    constructor(){
        super();
    }

    render(){
        return(
            <div>
                <h3>Login Form</h3>
                <form action="" method="POST">
                    <input type="email" placeholder='Enter your email'/>
                    <br/>
                    <input type="password" placeholder='Enter your password'/>
                    <br/>
                    <input type="submit"/>
                </form>
            </div>
        )
    }
}

export default Login;