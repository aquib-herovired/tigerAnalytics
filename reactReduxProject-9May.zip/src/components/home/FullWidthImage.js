export default function FullWidthImage(){
    return(
        <img src="https://images.unsplash.com/photo-1651765895131-1ae059a5f9ed?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" width="100%"/>
    )
}