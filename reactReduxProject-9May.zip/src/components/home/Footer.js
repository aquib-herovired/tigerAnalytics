export default function Footer(){
    return(
        <div style={{backgroundImage:"url('https://images.unsplash.com/photo-1651634038045-6444a9f91aa4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1032&q=80')", padding:"200px", display:"flex", justifyContent:"center", marginTop:"50px", backgroundSize:"cover"}}>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/qCNu_vJNLMQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    )
}