import ProductItem from "./ProductItem";

export default function ProductList(){
    return(
        <div style={{display:"flex", justifyContent:"space-around", marginTop:"50px", textAlign:"center"}}>
            <ProductItem src="https://images.unsplash.com/photo-1648737966636-2fc3a5fffc8a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" title="Game One" rating="4" description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt a mauris sit amet eleifend. Maecenas ac convallis turpis, at gravida magna. Cras ut mauris nec mi egestas imperdiet."/>
            <ProductItem src="https://images.unsplash.com/photo-1648737966636-2fc3a5fffc8a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" title="Game Two" rating="2" description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt a mauris sit amet eleifend. Maecenas ac convallis turpis, at gravida magna. Cras ut mauris nec mi egestas imperdiet."/>
            <ProductItem src="https://images.unsplash.com/photo-1648737966636-2fc3a5fffc8a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" title="Game Three" rating="4.5" description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt a mauris sit amet eleifend. Maecenas ac convallis turpis, at gravida magna. Cras ut mauris nec mi egestas imperdiet."/>
        </div>
    )
}