import { Link } from "react-router-dom";

export default function ProductItem(props){
    return(
        <div>
            <img width="300px" src={props.src}/>
            <h4>{props.title}</h4>
            <p>{props.description}</p>
            <p>Rating : {props.rating}/5</p>
            <Link to='/showDetails' >
                <button>View Details</button>
            </Link>
        </div>
    )
}