import Footer from "./home/Footer";
import FullWidthImage from "./home/FullWidthImage";
import Header from "./home/Header";
import ProductList from "./home/ProductList";

export default function Home(){
    return(
        <div>
            <Header/>
            <FullWidthImage/>
            <ProductList />
            <Footer />
        </div>
    )
}