export default function ShowDetails(props){
    return(
        <div>
            <img width="300px" src={props.src}/>
            <h4>{props.title}</h4>
            <p>{props.description}</p>
            <p>Rating : {props.rating}/5</p>
            <button>Buy Now for Rs. {props.price}/-</button>
        </div>
    )
}