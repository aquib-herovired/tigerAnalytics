import React, {Component} from 'react'

class Signup extends Component{
    constructor(){
        super();
    }

    render(){
        return(
            <div>
                <h3>Signup Form</h3>
                <form action="" method="POST">
                    <input type="text" placeholder='Enter your name'/>
                    <br/>
                    <input type="phone" placeholder='Enter your phone'/>
                    <br/>
                    <input type="email" placeholder='Enter your email'/>
                    <br/>
                    <input type="password" placeholder='Enter your password'/>
                    <br/>
                    <input type="submit"/>
                </form>
            </div>
        )
    }
}

export default Signup;