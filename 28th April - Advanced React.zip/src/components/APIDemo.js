import React, {Component} from 'react';
class APIDemo extends Component{
    constructor(){
        super();
        this.state = {
            users:[]
        }
    }
    render(){
        fetch("https://randomuser.me/api")
        .then(response=>response.json())
        .then(data=>console.log(data));
        return(
            <p>{this.state.users.length}</p>
        );
    };
}
export default APIDemo;