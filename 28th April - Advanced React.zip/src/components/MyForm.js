import React, {Component} from 'react'

class MyForm extends Component{
    constructor(){
        super();
        this.state = {
            name:'',
            email:'',
            isValidated:false
        }
        this.changeName = this.changeName.bind(this);
        this.changeEmail = this.changeEmail.bind(this);
        this.validateForm = this.validateForm.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    changeName(e){
        this.setState({
            name:e.target.value
        });
        console.log(this.state.name);
    }
    changeEmail(e){
        this.setState({
            email:e.target.value
        });
        console.log(this.state.email);
    }

    validateForm(){
        if(this.state.name.length==0 || this.state.email.length==0)
            this.setState({
                isValidated:false
            });
        else
            this.setState({
                isValidated:true
            });
    }

    handleSubmit(e){
        e.preventDefault();
        this.validateForm();
        console.log(this.state.isValidated);
        if(this.state.isValidated)
            e.target.submit();
        else
            console.log('Form not submitted');
    }
    render() {
        return (
             <form onSubmit={this.handleSubmit}>
                 <input type="text" value={this.state.name} onChange={this.changeName}/>
                 <input type="email" value={this.state.email} onChange={this.changeEmail}/>
                 <input type="submit"/>
             </form>
        );
    }
}

export default MyForm;