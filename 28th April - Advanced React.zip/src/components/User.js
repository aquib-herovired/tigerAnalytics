import React, { Component } from 'react';

class User extends Component{
    constructor(props)
    {
        super(props);
        this.state={
            name:"John",
            userBG:"white",
            city:"Bangalore"
        }
        this.modifyCity = this.modifyCity.bind(this);
        console.log("User constructed!");
    }

    render(){
        console.log("User rendered!");
        return (
            <div>
                <p style={{backgroundColor:this.state.userBG}}>This is {this.state.name} from {this.state.city}.</p>
                <button onClick={this.modifyCity}>Click</button>
            </div>
        );
    }

    componentDidMount(){
        console.log("User mounted!");
    }

   
    shouldComponentUpdate()
    {
        console.log(this.state.city);
        if(this.state.city=="Bangalore")
        {
            console.log("Component not updated");
            return false;
        }
        else
        {
            console.log("Component updated");
            return true;
        }
    }

    getSnapshotBeforeUpdate()
    {
        console.log("Snapshot taken");
    }

    componentDidUpdate(){
        console.log("Updated!");
    }

    modifyCity(){
        console.log("City modified!");
        this.setState({
            city:"Pune",
            userBG:"yellow"
        });
        console.log(this.state.city);
    }
    
    componentWillUnmount(){
        console.log("Unmounting...");
    }
}

export default User;