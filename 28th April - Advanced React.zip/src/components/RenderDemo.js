import React, {Component} from 'react';

class RenderDemo extends Component{
    constructor()
    {
        super();
        this.state={
            userLoggedIn:true
        }
    }
    render(){
        return this.state.userLoggedIn ? <p>The flag is true!</p> : <p>THis is when the flag is false!</p>;
        // if(this.state.flag)
        // {
        //     return(
        //         <p>The flag is true!</p>
        //     )
        // }
        // else return(
        //     <p>THis is when the flag is false!</p>
        // );
    }
}

export default RenderDemo;