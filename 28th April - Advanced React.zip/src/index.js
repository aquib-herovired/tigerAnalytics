import React from 'react';
import ReactDOM from 'react-dom/client';
import APIDemo from './components/APIDemo';
import './index.css';
// import App from './App';
// import User from './components/User'
// import RenderDemo from './components/RenderDemo';
// import MyForm from './components/MyForm';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
    {/* <User city="Chennai"/> */}
    {/* <RenderDemo /> */}
    {/* <MyForm /> */}
    
    {/* <APIDemo /> */}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
