import Container from 'react-bootstrap/Container';
import Col from 'react-bootstrap/esm/Col';
import Row from 'react-bootstrap/esm/Row';
import { useParams } from 'react-router';
import BackButton from '../BackButton';
import './ArticlePost.css';

function ArticlePost(){

    var {id} = useParams();

    var blogPosts = [
        {
            postid:100,
            content:'This is Blog 1 content'
        },
        {
            postid:101,
            content:'This is Blog 2 content'
        },
        {
            postid:102,
            content:'This is Blog 3 content'
        }
    ];

    return(
        <>
            {
                blogPosts.map(
                (el)=>{
                        if(el.postid==id)
                        {
                            console.log(el.content);
                            return <p>{el.content}</p>
                        }
                      }
                )
            }
            <BackButton />
        </>
    );
}

export default ArticlePost;