import { useNavigate } from "react-router-dom"

export default function BackButton(){

    const navigate = useNavigate();

    return(
        <>
            <button onClick={()=>{navigate(-1)}}>Go back</button>
            <button onClick={()=>{navigate(1)}}>Go forward</button>
        </>
    )
}