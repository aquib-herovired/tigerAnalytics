import About from './components/About';
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Categories from './components/Categories';
import ArticlesList from './components/articles/ArticlesList';
import ArticlePost from './components/articles/ArticlePost';
import Subscribe from './components/Subscribe';
import Article from './components/articles/ArticlePost';

function App() {
  return (
    <BrowserRouter>
        <Routes>
            {/* <Route path="/about" element={<About/>}></Route> */}
            {/* <Route path="/categories" element={<Categories/>}></Route> */}
            <Route path="/articles" element={<ArticlesList/>}></Route>
            <Route path="/articles/:id" element={<ArticlePost/>}></Route>
            {/* <Route path="/subscribe" element={<Subscribe/>}></Route> */}
        </Routes>
    </BrowserRouter>
  );
}

export default App;
